var my_key = "bookmydoc1";
var coreurl = "http://gotaworkout.com/";
var baseurl = coreurl+"index.php";

//http://www.bookmydoc.techware.in/